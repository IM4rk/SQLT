REM $Header: 215187.1 sqlt_s96902_tc_script.sql 12.1.160429 2018/04/05 abel.macias $

VAR   B                               VARCHAR2(32);
EXEC :B                               := 'SYNONYM';


select /* ^^unique_id */ count(object_type) from acs where object_type=:b;
