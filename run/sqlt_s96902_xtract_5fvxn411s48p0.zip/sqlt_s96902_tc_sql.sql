select count(object_type) from acs where object_type=:b;
