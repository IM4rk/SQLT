SP2-1504: Cannot print uninitialized LOB variable ":C2"
